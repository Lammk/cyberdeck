package com.cyberdeck;

import com.cyberdeck.capability.CyberdeckCapability;
import com.cyberdeck.client.ClientEventHandler;
import com.cyberdeck.client.KeyBindings;
import com.cyberdeck.items.CyberdeckItem;
import com.cyberdeck.network.PacketHandler;
import com.cyberdeck.quickhacks.QuickhackRegistry;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CyberdeckMod.MODID)
public class CyberdeckMod {
    public static final String MODID = "cyberdeck";
    
    public static final DeferredRegister<Item> ITEMS = 
        DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    
    public static final RegistryObject<Item> CYBERDECK_ITEM = 
        ITEMS.register("cyberdeck", () -> new CyberdeckItem(new Item.Properties().stacksTo(1)));
    
    public CyberdeckMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        ITEMS.register(modEventBus);
        
        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::addCreative);
        
        if (FMLEnvironment.dist == Dist.CLIENT) {
            modEventBus.addListener(this::clientSetup);
        }
        
        MinecraftForge.EVENT_BUS.register(this);
    }
    
    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            PacketHandler.register();
            QuickhackRegistry.register();
            CyberdeckCapability.register();
        });
    }
    
    private void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            KeyBindings.register();
            MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
        });
    }
    
    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(CYBERDECK_ITEM);
        }
    }
}

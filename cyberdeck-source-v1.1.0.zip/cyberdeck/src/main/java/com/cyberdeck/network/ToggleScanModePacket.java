package com.cyberdeck.network;

import com.cyberdeck.capability.CyberdeckCapability;
import com.cyberdeck.capability.ICyberdeckCapability;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ToggleScanModePacket {
    private final boolean enabled;
    
    public ToggleScanModePacket(boolean enabled) {
        this.enabled = enabled;
    }
    
    public static void encode(ToggleScanModePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.enabled);
    }
    
    public static ToggleScanModePacket decode(FriendlyByteBuf buf) {
        return new ToggleScanModePacket(buf.readBoolean());
    }
    
    public static void handle(ToggleScanModePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
                    cap.setScanModeActive(msg.enabled);
                    // Sync back to client
                    PacketHandler.sendToPlayer(new SyncScanModePacket(msg.enabled), player);
                });
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

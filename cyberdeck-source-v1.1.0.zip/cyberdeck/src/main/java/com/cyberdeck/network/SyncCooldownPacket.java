package com.cyberdeck.network;

import com.cyberdeck.capability.CyberdeckCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncCooldownPacket {
    private final String quickhackId;
    private final int cooldownTicks;
    
    public SyncCooldownPacket(String quickhackId, int cooldownTicks) {
        this.quickhackId = quickhackId;
        this.cooldownTicks = cooldownTicks;
    }
    
    public static void encode(SyncCooldownPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.quickhackId);
        buf.writeInt(msg.cooldownTicks);
    }
    
    public static SyncCooldownPacket decode(FriendlyByteBuf buf) {
        return new SyncCooldownPacket(buf.readUtf(), buf.readInt());
    }
    
    public static void handle(SyncCooldownPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            Player player = Minecraft.getInstance().player;
            if (player != null) {
                player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
                    cap.setCooldown(msg.quickhackId, msg.cooldownTicks);
                });
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

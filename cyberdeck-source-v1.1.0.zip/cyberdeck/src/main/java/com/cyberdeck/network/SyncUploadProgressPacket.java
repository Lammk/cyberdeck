package com.cyberdeck.network;

import com.cyberdeck.client.ClientUploadTracker;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncUploadProgressPacket {
    private final int entityId;
    private final String quickhackId;
    private final int currentTicks;
    private final int totalTicks;
    private final boolean finished;
    
    public SyncUploadProgressPacket(int entityId, String quickhackId, int currentTicks, int totalTicks, boolean finished) {
        this.entityId = entityId;
        this.quickhackId = quickhackId;
        this.currentTicks = currentTicks;
        this.totalTicks = totalTicks;
        this.finished = finished;
    }
    
    public static void encode(SyncUploadProgressPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.entityId);
        buf.writeUtf(msg.quickhackId);
        buf.writeInt(msg.currentTicks);
        buf.writeInt(msg.totalTicks);
        buf.writeBoolean(msg.finished);
    }
    
    public static SyncUploadProgressPacket decode(FriendlyByteBuf buf) {
        return new SyncUploadProgressPacket(
            buf.readInt(),
            buf.readUtf(),
            buf.readInt(),
            buf.readInt(),
            buf.readBoolean()
        );
    }
    
    public static void handle(SyncUploadProgressPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (msg.finished) {
                ClientUploadTracker.clearUpload();
            } else {
                ClientUploadTracker.setUpload(msg.entityId, msg.quickhackId, msg.currentTicks, msg.totalTicks);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

package com.cyberdeck.network;

import com.cyberdeck.capability.CyberdeckCapability;
import com.cyberdeck.quickhacks.Quickhack;
import com.cyberdeck.quickhacks.QuickhackManager;
import com.cyberdeck.quickhacks.QuickhackRegistry;
import com.cyberdeck.util.EntityTargeting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CastQuickhackPacket {
    private final String quickhackId;
    
    public CastQuickhackPacket(String quickhackId) {
        this.quickhackId = quickhackId;
    }
    
    public static void encode(CastQuickhackPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.quickhackId);
    }
    
    public static CastQuickhackPacket decode(FriendlyByteBuf buf) {
        return new CastQuickhackPacket(buf.readUtf());
    }
    
    public static void handle(CastQuickhackPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            
            Quickhack quickhack = QuickhackRegistry.getQuickhack(msg.quickhackId);
            if (quickhack == null) return;
            
            player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
                // Check cooldown
                if (cap.isOnCooldown(msg.quickhackId)) {
                    return;
                }
                
                // Find target
                LivingEntity target = EntityTargeting.getTargetedEntity(player, 25.0);
                if (target == null) {
                    return;
                }
                
                // Start upload
                QuickhackManager manager = QuickhackManager.get(player.level());
                manager.startUpload(player, target, quickhack);
                
                // Set cooldown
                cap.setCooldown(msg.quickhackId, quickhack.getCooldownTicks());
                
                // Sync cooldown to client
                PacketHandler.sendToPlayer(
                    new SyncCooldownPacket(msg.quickhackId, quickhack.getCooldownTicks()), 
                    player
                );
            });
        });
        ctx.get().setPacketHandled(true);
    }
}

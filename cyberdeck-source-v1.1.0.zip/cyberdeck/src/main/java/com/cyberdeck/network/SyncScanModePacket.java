package com.cyberdeck.network;

import com.cyberdeck.capability.CyberdeckCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncScanModePacket {
    private final boolean enabled;
    
    public SyncScanModePacket(boolean enabled) {
        this.enabled = enabled;
    }
    
    public static void encode(SyncScanModePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.enabled);
    }
    
    public static SyncScanModePacket decode(FriendlyByteBuf buf) {
        return new SyncScanModePacket(buf.readBoolean());
    }
    
    public static void handle(SyncScanModePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            Player player = Minecraft.getInstance().player;
            if (player != null) {
                player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
                    cap.setScanModeActive(msg.enabled);
                });
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

package com.cyberdeck.items;

import com.cyberdeck.client.gui.CyberdeckScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class CyberdeckItem extends Item implements Equipable {
    private static final int INTERNAL_SLOTS = 6; // For future extensions
    
    public CyberdeckItem(Properties properties) {
        super(properties);
    }
    
    @Override
    public EquipmentSlot getEquipmentSlot() {
        return EquipmentSlot.HEAD;
    }
    
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        
        if (level.isClientSide && hand == InteractionHand.MAIN_HAND) {
            openGui();
        }
        
        return InteractionResultHolder.success(stack);
    }
    
    @OnlyIn(Dist.CLIENT)
    private void openGui() {
        Minecraft.getInstance().setScreen(new CyberdeckScreen());
    }
    
    // Internal inventory structure for future extensions
    public static ItemStack getStackInSlot(ItemStack cyberdeck, int slot) {
        if (slot < 0 || slot >= INTERNAL_SLOTS) {
            return ItemStack.EMPTY;
        }
        
        CompoundTag tag = cyberdeck.getOrCreateTag();
        if (!tag.contains("Inventory")) {
            return ItemStack.EMPTY;
        }
        
        ListTag inventory = tag.getList("Inventory", 10);
        if (slot < inventory.size()) {
            CompoundTag slotTag = inventory.getCompound(slot);
            return ItemStack.of(slotTag);
        }
        
        return ItemStack.EMPTY;
    }
    
    public static void setStackInSlot(ItemStack cyberdeck, int slot, ItemStack stack) {
        if (slot < 0 || slot >= INTERNAL_SLOTS) {
            return;
        }
        
        CompoundTag tag = cyberdeck.getOrCreateTag();
        ListTag inventory;
        
        if (tag.contains("Inventory")) {
            inventory = tag.getList("Inventory", 10);
        } else {
            inventory = new ListTag();
        }
        
        // Ensure list is large enough
        while (inventory.size() <= slot) {
            inventory.add(new CompoundTag());
        }
        
        CompoundTag slotTag = new CompoundTag();
        stack.save(slotTag);
        inventory.set(slot, slotTag);
        
        tag.put("Inventory", inventory);
    }
    
    public static int getInternalSlots() {
        return INTERNAL_SLOTS;
    }
}

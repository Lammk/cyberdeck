package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class RebootOpticsQuickhack implements Quickhack {
    
    @Override
    public String getId() {
        return "reboot_optics";
    }
    
    @Override
    public String getName() {
        return "Reboot Optics";
    }
    
    @Override
    public int getCooldownTicks() {
        return 200; // 10 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 6; // 0.3 seconds
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        // Apply blindness for 10 seconds
        target.addEffect(new MobEffectInstance(
            MobEffects.BLINDNESS,
            200, // 10 seconds
            0,
            false,
            true,
            true
        ));
        
        if (caster.level() instanceof ServerLevel serverLevel) {
            // Dark smoke particles
            serverLevel.sendParticles(
                ParticleTypes.SMOKE,
                target.getX(), target.getY() + target.getBbHeight() * 0.8, target.getZ(),
                20,
                0.2, 0.2, 0.2,
                0.02
            );
            
            // Squid ink particles for extra effect
            serverLevel.sendParticles(
                ParticleTypes.SQUID_INK,
                target.getX(), target.getY() + target.getBbHeight() * 0.8, target.getZ(),
                15,
                0.3, 0.3, 0.3,
                0.05
            );
            
            // Distortion sound
            serverLevel.playSound(
                null,
                target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENDER_EYE_DEATH,
                SoundSource.HOSTILE,
                1.0f,
                0.8f
            );
        }
    }
}

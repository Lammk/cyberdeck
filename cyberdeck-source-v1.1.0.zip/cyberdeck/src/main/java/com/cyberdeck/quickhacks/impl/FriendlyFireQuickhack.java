package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

public class FriendlyFireQuickhack implements Quickhack {
    
    @Override
    public String getId() {
        return "friendly_fire";
    }
    
    @Override
    public String getName() {
        return "Friendly Fire";
    }
    
    @Override
    public int getCooldownTicks() {
        return 400; // 20 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 100; // 5 seconds
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        if (!(target instanceof Mob mob)) return;
        
        // Mark this mob as affected by Friendly Fire
        FriendlyFireTracker.addAffectedMob(mob, 600); // 30 seconds duration
        
        if (caster.level() instanceof ServerLevel serverLevel) {
            // Confusion particles
            serverLevel.sendParticles(
                ParticleTypes.ANGRY_VILLAGER,
                target.getX(), target.getY() + target.getBbHeight() + 0.5, target.getZ(),
                10,
                0.5, 0.2, 0.5,
                0
            );
            
            serverLevel.sendParticles(
                ParticleTypes.ENCHANT,
                target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                30,
                0.5, 0.5, 0.5,
                0.5
            );
            
            // Confusion sound
            serverLevel.playSound(
                null,
                target.getX(), target.getY(), target.getZ(),
                SoundEvents.ILLUSIONER_CAST_SPELL,
                SoundSource.HOSTILE,
                1.0f,
                1.2f
            );
        }
    }
    
    @Mod.EventBusSubscriber
    public static class FriendlyFireTracker {
        private static final Map<UUID, Integer> affectedMobs = new HashMap<>();
        private static final Map<UUID, GoalData> originalGoals = new HashMap<>();
        
        public static void addAffectedMob(Mob mob, int duration) {
            UUID id = mob.getUUID();
            affectedMobs.put(id, duration);
            
            // Store original goals
            if (!originalGoals.containsKey(id)) {
                originalGoals.put(id, new GoalData());
            }
            
            // Clear existing target goals and add new hostile mob targeting
            mob.targetSelector.getAvailableGoals().clear();
            mob.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(
                mob,
                Monster.class,
                true,
                (entity) -> entity != mob && !(entity instanceof Player)
            ));
        }
        
        @SubscribeEvent
        public static void onLivingUpdate(LivingEvent.LivingTickEvent event) {
            if (!(event.getEntity() instanceof Mob mob)) return;
            if (mob.level().isClientSide) return;
            
            UUID id = mob.getUUID();
            
            if (affectedMobs.containsKey(id)) {
                int timeLeft = affectedMobs.get(id) - 1;
                
                if (timeLeft <= 0) {
                    // Effect expired, restore original behavior
                    affectedMobs.remove(id);
                    restoreOriginalGoals(mob, id);
                } else {
                    affectedMobs.put(id, timeLeft);
                    
                    // Ensure mob doesn't target players
                    if (mob.getTarget() instanceof Player) {
                        mob.setTarget(null);
                    }
                }
            }
        }
        
        private static void restoreOriginalGoals(Mob mob, UUID id) {
            mob.targetSelector.getAvailableGoals().clear();
            originalGoals.remove(id);
            
            // Re-register default goals (this is basic, real implementation would need proper goal restoration)
            if (mob instanceof Monster) {
                mob.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(mob, Player.class, true));
            }
        }
        
        private static class GoalData {
            // Placeholder for storing original AI goals
        }
    }
}

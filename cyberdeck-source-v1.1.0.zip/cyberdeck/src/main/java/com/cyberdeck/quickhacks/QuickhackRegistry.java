package com.cyberdeck.quickhacks;

import com.cyberdeck.quickhacks.impl.*;

import java.util.*;

public class QuickhackRegistry {
    private static final Map<String, Quickhack> QUICKHACKS = new LinkedHashMap<>();
    
    public static void register() {
        registerQuickhack(new PingQuickhack());
        registerQuickhack(new OverheatQuickhack());
        registerQuickhack(new ShortCircuitQuickhack());
        registerQuickhack(new AttackGlitchQuickhack());
        registerQuickhack(new RebootOpticsQuickhack());
        registerQuickhack(new FriendlyFireQuickhack());
    }
    
    private static void registerQuickhack(Quickhack quickhack) {
        QUICKHACKS.put(quickhack.getId(), quickhack);
    }
    
    public static Quickhack getQuickhack(String id) {
        return QUICKHACKS.get(id);
    }
    
    public static List<Quickhack> getAllQuickhacks() {
        return new ArrayList<>(QUICKHACKS.values());
    }
}

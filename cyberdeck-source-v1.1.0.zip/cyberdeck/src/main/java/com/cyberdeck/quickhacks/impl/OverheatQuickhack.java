package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class OverheatQuickhack implements Quickhack {
    
    @Override
    public String getId() {
        return "overheat";
    }
    
    @Override
    public String getName() {
        return "Overheat";
    }
    
    @Override
    public int getCooldownTicks() {
        return 400; // 20 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 5; // 0.25 seconds
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        // Set target on fire for 15 seconds
        target.setSecondsOnFire(15);
        
        if (caster.level() instanceof ServerLevel serverLevel) {
            // Fire particles
            serverLevel.sendParticles(
                ParticleTypes.FLAME,
                target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                30,
                0.3, 0.5, 0.3,
                0.05
            );
            
            // Sound effect
            serverLevel.playSound(
                null,
                target.getX(), target.getY(), target.getZ(),
                SoundEvents.FIRECHARGE_USE,
                SoundSource.HOSTILE,
                1.0f,
                1.0f
            );
        }
    }
}

package com.cyberdeck.quickhacks;

import com.cyberdeck.network.PacketHandler;
import com.cyberdeck.network.SyncUploadProgressPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

@Mod.EventBusSubscriber
public class QuickhackManager {
    private static final Map<Level, QuickhackManager> INSTANCES = new HashMap<>();
    
    private final Map<UUID, UploadData> activeUploads = new HashMap<>();
    
    public static QuickhackManager get(Level level) {
        return INSTANCES.computeIfAbsent(level, l -> new QuickhackManager());
    }
    
    public void startUpload(ServerPlayer caster, LivingEntity target, Quickhack quickhack) {
        UUID casterId = caster.getUUID();
        
        UploadData data = new UploadData(
            caster,
            target,
            quickhack,
            quickhack.getUploadTimeTicks()
        );
        
        activeUploads.put(casterId, data);
        
        // Send initial progress
        syncProgress(caster, data, false);
    }
    
    public void cancelUpload(UUID casterId) {
        UploadData data = activeUploads.remove(casterId);
        if (data != null && data.caster instanceof ServerPlayer) {
            PacketHandler.sendToPlayer(
                new SyncUploadProgressPacket(0, "", 0, 0, true),
                (ServerPlayer) data.caster
            );
        }
    }
    
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        
        for (QuickhackManager manager : INSTANCES.values()) {
            manager.tick();
        }
    }
    
    private void tick() {
        Iterator<Map.Entry<UUID, UploadData>> iterator = activeUploads.entrySet().iterator();
        
        while (iterator.hasNext()) {
            Map.Entry<UUID, UploadData> entry = iterator.next();
            UploadData data = entry.getValue();
            
            // Check if upload should be cancelled
            if (!data.target.isAlive() || 
                data.caster.distanceTo(data.target) > 30.0 ||
                !data.caster.isAlive()) {
                
                if (data.caster instanceof ServerPlayer) {
                    PacketHandler.sendToPlayer(
                        new SyncUploadProgressPacket(0, "", 0, 0, true),
                        (ServerPlayer) data.caster
                    );
                }
                iterator.remove();
                continue;
            }
            
            data.ticksRemaining--;
            
            // Sync progress
            if (data.caster instanceof ServerPlayer) {
                syncProgress((ServerPlayer) data.caster, data, false);
            }
            
            // Execute when complete
            if (data.ticksRemaining <= 0) {
                data.quickhack.execute(data.caster, data.target);
                
                if (data.caster instanceof ServerPlayer) {
                    PacketHandler.sendToPlayer(
                        new SyncUploadProgressPacket(0, "", 0, 0, true),
                        (ServerPlayer) data.caster
                    );
                }
                
                iterator.remove();
            }
        }
    }
    
    private void syncProgress(ServerPlayer caster, UploadData data, boolean finished) {
        int currentTicks = data.totalTicks - data.ticksRemaining;
        PacketHandler.sendToPlayer(
            new SyncUploadProgressPacket(
                data.target.getId(),
                data.quickhack.getId(),
                currentTicks,
                data.totalTicks,
                finished
            ),
            caster
        );
    }
    
    private static class UploadData {
        final LivingEntity caster;
        final LivingEntity target;
        final Quickhack quickhack;
        final int totalTicks;
        int ticksRemaining;
        
        UploadData(LivingEntity caster, LivingEntity target, Quickhack quickhack, int ticks) {
            this.caster = caster;
            this.target = target;
            this.quickhack = quickhack;
            this.totalTicks = ticks;
            this.ticksRemaining = ticks;
        }
    }
}

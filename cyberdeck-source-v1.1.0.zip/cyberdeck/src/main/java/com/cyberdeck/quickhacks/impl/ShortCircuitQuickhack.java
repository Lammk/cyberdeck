package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.Random;

public class ShortCircuitQuickhack implements Quickhack {
    private static final Random RANDOM = new Random();
    
    @Override
    public String getId() {
        return "short_circuit";
    }
    
    @Override
    public String getName() {
        return "Short Circuit";
    }
    
    @Override
    public int getCooldownTicks() {
        return 200; // 10 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 60; // 3 seconds
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        // Random damage between 20-50 HP (10-25 hearts)
        float damage = 20.0f + RANDOM.nextFloat() * 30.0f;
        
        target.hurt(caster.damageSources().lightningBolt(), damage);
        
        if (caster.level() instanceof ServerLevel serverLevel) {
            // Electric spark particles
            serverLevel.sendParticles(
                ParticleTypes.ELECTRIC_SPARK,
                target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                50,
                0.5, 0.5, 0.5,
                0.3
            );
            
            // Additional electric effects
            serverLevel.sendParticles(
                ParticleTypes.SOUL_FIRE_FLAME,
                target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                20,
                0.3, 0.5, 0.3,
                0.1
            );
            
            // Lightning sound
            serverLevel.playSound(
                null,
                target.getX(), target.getY(), target.getZ(),
                SoundEvents.LIGHTNING_BOLT_IMPACT,
                SoundSource.HOSTILE,
                0.5f,
                1.5f + RANDOM.nextFloat() * 0.4f
            );
        }
    }
}

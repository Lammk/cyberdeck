package com.cyberdeck.quickhacks;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public interface Quickhack {
    
    /**
     * Unique identifier for this quickhack
     */
    String getId();
    
    /**
     * Display name for the UI
     */
    String getName();
    
    /**
     * Cooldown in ticks (20 ticks = 1 second)
     */
    int getCooldownTicks();
    
    /**
     * Upload time in ticks before effect triggers
     */
    int getUploadTimeTicks();
    
    /**
     * Execute the quickhack effect on the target
     */
    void execute(Player caster, LivingEntity target);
    
    /**
     * Check if quickhack can be cast on this target
     */
    default boolean canCastOn(LivingEntity target) {
        return target != null && target.isAlive();
    }
}

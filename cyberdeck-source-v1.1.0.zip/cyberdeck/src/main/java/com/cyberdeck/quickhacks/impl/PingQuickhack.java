package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class PingQuickhack implements Quickhack {
    
    @Override
    public String getId() {
        return "ping";
    }
    
    @Override
    public String getName() {
        return "Ping";
    }
    
    @Override
    public int getCooldownTicks() {
        return 200; // 10 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 1; // Instant
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        if (!(caster.level() instanceof ServerLevel serverLevel)) return;
        
        // Find all mobs within 100 blocks
        AABB searchBox = new AABB(
            caster.getX() - 100, caster.getY() - 100, caster.getZ() - 100,
            caster.getX() + 100, caster.getY() + 100, caster.getZ() + 100
        );
        
        List<Mob> mobs = serverLevel.getEntitiesOfClass(Mob.class, searchBox);
        
        // Apply glowing effect for 30 seconds
        for (Mob mob : mobs) {
            mob.addEffect(new MobEffectInstance(
                MobEffects.GLOWING,
                600, // 30 seconds
                0,
                false,
                false,
                true
            ));
            
            // Spawn particles at target
            serverLevel.sendParticles(
                ParticleTypes.ELECTRIC_SPARK,
                mob.getX(), mob.getY() + mob.getBbHeight() / 2, mob.getZ(),
                10,
                0.3, 0.3, 0.3,
                0.1
            );
        }
    }
}

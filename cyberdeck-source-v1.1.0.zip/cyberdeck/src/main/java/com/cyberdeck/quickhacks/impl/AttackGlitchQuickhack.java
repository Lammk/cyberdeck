package com.cyberdeck.quickhacks.impl;

import com.cyberdeck.quickhacks.Quickhack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class AttackGlitchQuickhack implements Quickhack {
    
    @Override
    public String getId() {
        return "attack_glitch";
    }
    
    @Override
    public String getName() {
        return "Attack Glitch";
    }
    
    @Override
    public int getCooldownTicks() {
        return 200; // 10 seconds
    }
    
    @Override
    public int getUploadTimeTicks() {
        return 6; // 0.3 seconds
    }
    
    @Override
    public void execute(Player caster, LivingEntity target) {
        // Reduce attack speed with Mining Fatigue (slower attacks)
        target.addEffect(new MobEffectInstance(
            MobEffects.DIG_SLOWDOWN,
            300, // 15 seconds
            2,
            false,
            true,
            true
        ));
        
        // Reduce damage with Weakness
        target.addEffect(new MobEffectInstance(
            MobEffects.WEAKNESS,
            300, // 15 seconds
            1,
            false,
            true,
            true
        ));
        
        if (caster.level() instanceof ServerLevel serverLevel) {
            // Glitch particles
            serverLevel.sendParticles(
                ParticleTypes.PORTAL,
                target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(),
                30,
                0.5, 0.5, 0.5,
                0.5
            );
            
            // Distortion sound
            serverLevel.playSound(
                null,
                target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.HOSTILE,
                0.7f,
                0.5f
            );
        }
    }
}

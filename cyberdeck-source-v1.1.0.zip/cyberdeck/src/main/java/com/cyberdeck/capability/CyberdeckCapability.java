package com.cyberdeck.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

public class CyberdeckCapability {
    public static Capability<ICyberdeckCapability> INSTANCE = 
        CapabilityManager.get(new CapabilityToken<>(){});
    
    public static void register() {
        // Capability is automatically registered via CapabilityToken
    }
    
    @Mod.EventBusSubscriber
    public static class EventHandler {
        @SubscribeEvent
        public static void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
            if (event.getObject() instanceof Player) {
                CyberdeckCapabilityProvider provider = new CyberdeckCapabilityProvider();
                event.addCapability(new ResourceLocation("cyberdeck", "data"), provider);
            }
        }
    }
    
    public static class CyberdeckCapabilityProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
        private final CyberdeckCapabilityImpl instance = new CyberdeckCapabilityImpl();
        private final LazyOptional<ICyberdeckCapability> holder = LazyOptional.of(() -> instance);
        
        @Override
        public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
            return CyberdeckCapability.INSTANCE.orEmpty(cap, holder);
        }
        
        @Override
        public CompoundTag serializeNBT() {
            CompoundTag tag = new CompoundTag();
            
            CompoundTag cooldowns = new CompoundTag();
            for (Map.Entry<String, Integer> entry : instance.cooldowns.entrySet()) {
                cooldowns.putInt(entry.getKey(), entry.getValue());
            }
            tag.put("Cooldowns", cooldowns);
            tag.putBoolean("ScanMode", instance.scanModeActive);
            
            return tag;
        }
        
        @Override
        public void deserializeNBT(CompoundTag tag) {
            if (tag.contains("Cooldowns")) {
                CompoundTag cooldowns = tag.getCompound("Cooldowns");
                instance.cooldowns.clear();
                for (String key : cooldowns.getAllKeys()) {
                    instance.cooldowns.put(key, cooldowns.getInt(key));
                }
            }
            instance.scanModeActive = tag.getBoolean("ScanMode");
        }
    }
    
    public static class CyberdeckCapabilityImpl implements ICyberdeckCapability {
        private final Map<String, Integer> cooldowns = new HashMap<>();
        private boolean scanModeActive = false;
        private String uploadingQuickhack = null;
        
        @Override
        public void setCooldown(String quickhackId, int ticks) {
            if (ticks > 0) {
                cooldowns.put(quickhackId, ticks);
            } else {
                cooldowns.remove(quickhackId);
            }
        }
        
        @Override
        public int getCooldown(String quickhackId) {
            return cooldowns.getOrDefault(quickhackId, 0);
        }
        
        @Override
        public boolean isOnCooldown(String quickhackId) {
            return getCooldown(quickhackId) > 0;
        }
        
        @Override
        public void tick() {
            cooldowns.entrySet().removeIf(entry -> {
                int newValue = entry.getValue() - 1;
                if (newValue <= 0) {
                    return true;
                }
                entry.setValue(newValue);
                return false;
            });
        }
        
        @Override
        public Map<String, Integer> getAllCooldowns() {
            return new HashMap<>(cooldowns);
        }
        
        @Override
        public void setScanModeActive(boolean active) {
            this.scanModeActive = active;
        }
        
        @Override
        public boolean isScanModeActive() {
            return scanModeActive;
        }
        
        @Override
        public void setUploadingQuickhack(String quickhackId) {
            this.uploadingQuickhack = quickhackId;
        }
        
        @Override
        public String getUploadingQuickhack() {
            return uploadingQuickhack;
        }
        
        @Override
        public void clearUpload() {
            this.uploadingQuickhack = null;
        }
    }
}

package com.cyberdeck.capability;

import java.util.Map;

public interface ICyberdeckCapability {
    
    // Cooldown management
    void setCooldown(String quickhackId, int ticks);
    int getCooldown(String quickhackId);
    boolean isOnCooldown(String quickhackId);
    void tick();
    Map<String, Integer> getAllCooldowns();
    
    // Scan mode
    void setScanModeActive(boolean active);
    boolean isScanModeActive();
    
    // Upload tracking
    void setUploadingQuickhack(String quickhackId);
    String getUploadingQuickhack();
    void clearUpload();
}

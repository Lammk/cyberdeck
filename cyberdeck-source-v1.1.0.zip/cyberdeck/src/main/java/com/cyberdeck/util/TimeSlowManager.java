package com.cyberdeck.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber
public class TimeSlowManager {
    private static final Map<UUID, SlowData> slowedEntities = new HashMap<>();
    private static final float SLOW_FACTOR = 0.15f; // 15% of normal speed (85% reduction)
    
    public static void setScanMode(Player player, boolean active) {
        UUID playerId = player.getUUID();
        
        if (active) {
            slowedEntities.put(playerId, new SlowData(player, true));
        } else {
            slowedEntities.remove(playerId);
        }
    }
    
    public static boolean isInScanMode(Player player) {
        return slowedEntities.containsKey(player.getUUID());
    }
    
    @SubscribeEvent
    public static void onLivingUpdate(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;
        
        // Check if any player has scan mode active
        boolean shouldSlow = false;
        for (SlowData data : slowedEntities.values()) {
            if (data.isPlayerInScanMode && data.player.level() == entity.level()) {
                shouldSlow = true;
                break;
            }
        }
        
        if (shouldSlow) {
            // Apply slowdown to all entities
            Vec3Wrapper motion = new Vec3Wrapper(entity.getDeltaMovement());
            motion.scale(SLOW_FACTOR);
            entity.setDeltaMovement(motion.toVec3());
            
            // Slow AI tick rate by skipping ticks
            if (entity.tickCount % 6 != 0) { // Only update AI every 6th tick
                // This creates a stuttering slow-motion effect
            }
        }
    }
    
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        
        Player player = event.player;
        UUID playerId = player.getUUID();
        
        if (slowedEntities.containsKey(playerId)) {
            // Slow the player's movement as well
            player.setDeltaMovement(player.getDeltaMovement().scale(SLOW_FACTOR));
        }
    }
    
    private static class SlowData {
        final Player player;
        final boolean isPlayerInScanMode;
        
        SlowData(Player player, boolean isPlayerInScanMode) {
            this.player = player;
            this.isPlayerInScanMode = isPlayerInScanMode;
        }
    }
    
    private static class Vec3Wrapper {
        double x, y, z;
        
        Vec3Wrapper(net.minecraft.world.phys.Vec3 vec) {
            this.x = vec.x;
            this.y = vec.y;
            this.z = vec.z;
        }
        
        void scale(float factor) {
            x *= factor;
            y *= factor;
            z *= factor;
        }
        
        net.minecraft.world.phys.Vec3 toVec3() {
            return new net.minecraft.world.phys.Vec3(x, y, z);
        }
    }
}

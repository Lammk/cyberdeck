package com.cyberdeck.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class EntityTargeting {
    
    /**
     * Get the entity the player is looking at within range
     * @param player The player
     * @param range Maximum distance
     * @return The targeted LivingEntity or null
     */
    public static LivingEntity getTargetedEntity(Player player, double range) {
        Vec3 eyePos = player.getEyePosition(1.0f);
        Vec3 lookVec = player.getViewVector(1.0f);
        Vec3 endPos = eyePos.add(lookVec.scale(range));
        
        // Create bounding box for entity search
        AABB searchBox = player.getBoundingBox().expandTowards(lookVec.scale(range)).inflate(1.0);
        
        // Find entity hit
        EntityHitResult result = ProjectileUtil.getEntityHitResult(
            player.level(),
            player,
            eyePos,
            endPos,
            searchBox,
            (entity) -> !entity.isSpectator() && entity.isPickable() && entity instanceof LivingEntity
        );
        
        if (result != null && result.getEntity() instanceof LivingEntity living) {
            // Check if there's a block in the way
            HitResult blockHit = player.level().clip(new ClipContext(
                eyePos,
                endPos,
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,
                player
            ));
            
            // If block is closer than entity, no target
            if (blockHit.getType() != HitResult.Type.MISS) {
                double blockDist = eyePos.distanceToSqr(blockHit.getLocation());
                double entityDist = eyePos.distanceToSqr(result.getLocation());
                if (blockDist < entityDist) {
                    return null;
                }
            }
            
            return living;
        }
        
        return null;
    }
}

package com.cyberdeck.client;

import com.cyberdeck.CyberdeckMod;
import com.cyberdeck.capability.CyberdeckCapability;
import com.cyberdeck.network.PacketHandler;
import com.cyberdeck.network.ToggleScanModePacket;
import com.cyberdeck.util.TimeSlowManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CyberdeckMod.MODID, value = Dist.CLIENT)
public class ClientEventHandler {
    private static boolean wasKeyDown = false;
    
    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        
        // Check for scan mode toggle
        if (KeyBindings.SCAN_MODE_KEY.isDown() && !wasKeyDown) {
            wasKeyDown = true;
            handleScanModeToggle(mc.player);
        } else if (!KeyBindings.SCAN_MODE_KEY.isDown()) {
            wasKeyDown = false;
        }
    }
    
    private static void handleScanModeToggle(Player player) {
        // Check if player has cyberdeck in main hand OR equipped as helmet
        ItemStack mainHand = player.getItemInHand(InteractionHand.MAIN_HAND);
        ItemStack helmet = player.getInventory().getArmor(3); // Head slot
        
        boolean hasCyberdeck = mainHand.getItem() == CyberdeckMod.CYBERDECK_ITEM.get() ||
                               helmet.getItem() == CyberdeckMod.CYBERDECK_ITEM.get();
        
        if (!hasCyberdeck) {
            return;
        }
        
        // Toggle scan mode
        player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
            boolean newState = !cap.isScanModeActive();
            cap.setScanModeActive(newState);
            
            // Send to server
            PacketHandler.sendToServer(new ToggleScanModePacket(newState));
            
            // Apply client-side effects
            TimeSlowManager.setScanMode(player, newState);
        });
    }
    
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        
        // Tick cooldowns
        mc.player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
            cap.tick();
        });
    }
}

package com.cyberdeck.client.gui;

import com.cyberdeck.capability.CyberdeckCapability;
import com.cyberdeck.client.ClientUploadTracker;
import com.cyberdeck.network.CastQuickhackPacket;
import com.cyberdeck.network.PacketHandler;
import com.cyberdeck.quickhacks.Quickhack;
import com.cyberdeck.quickhacks.QuickhackRegistry;
import com.cyberdeck.util.EntityTargeting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;

import java.util.List;

public class CyberdeckScreen extends Screen {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 30;
    private static final int BUTTON_SPACING = 5;
    
    private List<Quickhack> quickhacks;
    private LivingEntity targetEntity;
    
    public CyberdeckScreen() {
        super(Component.literal("Cyberdeck"));
        this.quickhacks = QuickhackRegistry.getAllQuickhacks();
    }
    
    @Override
    protected void init() {
        super.init();
        
        // Find target entity
        if (minecraft != null && minecraft.player != null) {
            targetEntity = EntityTargeting.getTargetedEntity(minecraft.player, 25.0);
        }
    }
    
    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        
        // Title
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0x00FFFF);
        
        // Target info
        if (targetEntity != null) {
            String targetName = targetEntity.getName().getString();
            graphics.drawCenteredString(
                this.font,
                Component.literal("Target: " + targetName),
                this.width / 2,
                40,
                0xFFFFFF
            );
        } else {
            graphics.drawCenteredString(
                this.font,
                Component.literal("No Target"),
                this.width / 2,
                40,
                0xFF0000
            );
        }
        
        // Upload progress bar
        if (ClientUploadTracker.isUploading()) {
            renderUploadProgress(graphics);
        }
        
        // Render quickhack buttons
        renderQuickhackButtons(graphics, mouseX, mouseY);
        
        super.render(graphics, mouseX, mouseY, partialTick);
    }
    
    private void renderQuickhackButtons(GuiGraphics graphics, int mouseX, int mouseY) {
        int startY = 70;
        int x = (this.width - BUTTON_WIDTH) / 2;
        
        for (int i = 0; i < quickhacks.size(); i++) {
            Quickhack qh = quickhacks.get(i);
            int y = startY + i * (BUTTON_HEIGHT + BUTTON_SPACING);
            
            // Get cooldown
            int cooldownTicks = 0;
            if (minecraft != null && minecraft.player != null) {
                minecraft.player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
                    // This is a workaround since we can't assign in lambda
                });
                
                // Direct access for rendering
                cooldownTicks = getCooldown(qh.getId());
            }
            
            boolean isOnCooldown = cooldownTicks > 0;
            boolean canCast = !isOnCooldown && targetEntity != null;
            
            // Button background
            int color = canCast ? 0x80404040 : 0x80202020;
            if (isHovering(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, mouseX, mouseY) && canCast) {
                color = 0x80606060;
            }
            
            graphics.fill(x, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, color);
            
            // Border
            int borderColor = canCast ? 0xFF00FFFF : 0xFF404040;
            graphics.renderOutline(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, borderColor);
            
            // Text
            String label = qh.getName();
            if (isOnCooldown) {
                float secondsLeft = cooldownTicks / 20.0f;
                label += String.format(" (%.1fs)", secondsLeft);
            }
            
            int textColor = canCast ? 0xFFFFFF : 0x808080;
            graphics.drawString(
                this.font,
                label,
                x + 10,
                y + (BUTTON_HEIGHT - 8) / 2,
                textColor
            );
        }
    }
    
    private void renderUploadProgress(GuiGraphics graphics) {
        float progress = ClientUploadTracker.getProgress();
        
        int barWidth = 200;
        int barHeight = 20;
        int x = (this.width - barWidth) / 2;
        int y = this.height - 50;
        
        // Background
        graphics.fill(x, y, x + barWidth, y + barHeight, 0x80000000);
        
        // Progress fill
        int fillWidth = (int) (barWidth * progress);
        graphics.fill(x, y, x + fillWidth, y + barHeight, 0xFF00FF00);
        
        // Border
        graphics.renderOutline(x, y, barWidth, barHeight, 0xFFFFFFFF);
        
        // Text
        String progressText = String.format("Uploading... %.0f%%", progress * 100);
        graphics.drawCenteredString(
            this.font,
            progressText,
            this.width / 2,
            y + 6,
            0xFFFFFF
        );
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return false; // Left click only
        
        int startY = 70;
        int x = (this.width - BUTTON_WIDTH) / 2;
        
        for (int i = 0; i < quickhacks.size(); i++) {
            Quickhack qh = quickhacks.get(i);
            int y = startY + i * (BUTTON_HEIGHT + BUTTON_SPACING);
            
            if (isHovering(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, (int)mouseX, (int)mouseY)) {
                if (tryExecuteQuickhack(qh)) {
                    this.onClose();
                    return true;
                }
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    private boolean tryExecuteQuickhack(Quickhack qh) {
        if (minecraft == null || minecraft.player == null) return false;
        if (targetEntity == null) return false;
        
        // Check cooldown
        if (getCooldown(qh.getId()) > 0) {
            return false;
        }
        
        // Send packet to server
        PacketHandler.sendToServer(new CastQuickhackPacket(qh.getId()));
        return true;
    }
    
    private int getCooldown(String quickhackId) {
        if (minecraft == null || minecraft.player == null) return 0;
        
        int[] cooldown = {0};
        minecraft.player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
            cooldown[0] = cap.getCooldown(quickhackId);
        });
        return cooldown[0];
    }
    
    private boolean isHovering(int x, int y, int width, int height, int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
    
    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

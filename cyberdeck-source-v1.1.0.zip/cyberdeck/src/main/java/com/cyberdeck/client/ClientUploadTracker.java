package com.cyberdeck.client;

public class ClientUploadTracker {
    private static int targetEntityId = -1;
    private static String quickhackId = "";
    private static int currentTicks = 0;
    private static int totalTicks = 0;
    private static boolean isUploading = false;
    
    public static void setUpload(int entityId, String qhId, int current, int total) {
        targetEntityId = entityId;
        quickhackId = qhId;
        currentTicks = current;
        totalTicks = total;
        isUploading = true;
    }
    
    public static void clearUpload() {
        targetEntityId = -1;
        quickhackId = "";
        currentTicks = 0;
        totalTicks = 0;
        isUploading = false;
    }
    
    public static boolean isUploading() {
        return isUploading;
    }
    
    public static int getTargetEntityId() {
        return targetEntityId;
    }
    
    public static String getQuickhackId() {
        return quickhackId;
    }
    
    public static float getProgress() {
        if (totalTicks == 0) return 0.0f;
        return (float) currentTicks / (float) totalTicks;
    }
    
    public static int getCurrentTicks() {
        return currentTicks;
    }
    
    public static int getTotalTicks() {
        return totalTicks;
    }
}

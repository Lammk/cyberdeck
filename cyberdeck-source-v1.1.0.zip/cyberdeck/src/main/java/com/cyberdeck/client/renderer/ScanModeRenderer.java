package com.cyberdeck.client.renderer;

import com.cyberdeck.capability.CyberdeckCapability;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT)
public class ScanModeRenderer {
    
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;
        
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        
        mc.player.getCapability(CyberdeckCapability.INSTANCE).ifPresent(cap -> {
            if (cap.isScanModeActive()) {
                renderScanModeOverlay(event.getGuiGraphics(), mc);
            }
        });
    }
    
    private static void renderScanModeOverlay(GuiGraphics graphics, Minecraft mc) {
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        
        // Dark overlay with cyan tint
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        // Pulsing effect
        float time = (System.currentTimeMillis() % 2000) / 2000.0f;
        float pulse = (float) (Math.sin(time * Math.PI * 2) * 0.5 + 0.5);
        
        // Dark vignette overlay
        int alpha = (int) (100 + pulse * 30);
        int color = (alpha << 24) | 0x001a1a; // Dark cyan tint
        
        graphics.fill(0, 0, width, height, color);
        
        // Corner brackets for cyberpunk effect
        renderCornerBrackets(graphics, width, height, pulse);
        
        // Scan lines effect
        renderScanLines(graphics, width, height, time);
        
        RenderSystem.disableBlend();
    }
    
    private static void renderCornerBrackets(GuiGraphics graphics, int width, int height, float pulse) {
        int bracketSize = 30;
        int thickness = 2;
        int color = 0xFF00FFFF | ((int)(pulse * 50 + 205) << 24);
        
        // Top-left
        graphics.fill(10, 10, 10 + bracketSize, 10 + thickness, color);
        graphics.fill(10, 10, 10 + thickness, 10 + bracketSize, color);
        
        // Top-right
        graphics.fill(width - 10 - bracketSize, 10, width - 10, 10 + thickness, color);
        graphics.fill(width - 10 - thickness, 10, width - 10, 10 + bracketSize, color);
        
        // Bottom-left
        graphics.fill(10, height - 10 - thickness, 10 + bracketSize, height - 10, color);
        graphics.fill(10, height - 10 - bracketSize, 10 + thickness, height - 10, color);
        
        // Bottom-right
        graphics.fill(width - 10 - bracketSize, height - 10 - thickness, width - 10, height - 10, color);
        graphics.fill(width - 10 - thickness, height - 10 - bracketSize, width - 10, height - 10, color);
    }
    
    private static void renderScanLines(GuiGraphics graphics, int width, int height, float time) {
        int lineSpacing = 4;
        int offset = (int) (time * height * 2) % lineSpacing;
        
        for (int y = -offset; y < height; y += lineSpacing) {
            graphics.fill(0, y, width, y + 1, 0x20FFFFFF);
        }
    }
}

# Cyberdeck Mod - System Architecture Diagrams

## High-Level System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        CYBERDECK MOD                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │
│  │   CORE ITEM  │    │  SCAN MODE   │    │  QUICKHACKS  │     │
│  │              │    │              │    │              │     │
│  │ - Cyberdeck  │    │ - Z Key      │    │ - 6 Hacks    │     │
│  │ - Inventory  │    │ - Time Slow  │    │ - Cooldowns  │     │
│  │ - GUI        │    │ - Visuals    │    │ - Uploads    │     │
│  └──────────────┘    └──────────────┘    └──────────────┘     │
│         │                    │                    │             │
│         └────────────────────┴────────────────────┘             │
│                              │                                  │
│                    ┌─────────▼─────────┐                        │
│                    │   CAPABILITY      │                        │
│                    │  (Player Data)    │                        │
│                    │                   │                        │
│                    │ - Cooldowns       │                        │
│                    │ - Scan State      │                        │
│                    │ - Upload State    │                        │
│                    └─────────┬─────────┘                        │
│                              │                                  │
│                    ┌─────────▼─────────┐                        │
│                    │   NETWORKING      │                        │
│                    │                   │                        │
│                    │ Client ←→ Server  │                        │
│                    │   Sync Packets    │                        │
│                    └───────────────────┘                        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Client-Server Architecture

```
CLIENT SIDE                           SERVER SIDE
═══════════                           ═══════════

┌─────────────────┐                 ┌─────────────────┐
│  Key Input      │                 │  Packet Handler │
│  (Z pressed)    │────────────────▶│  Validates      │
└─────────────────┘                 │  Processes      │
        │                            └─────────────────┘
        │                                     │
        ▼                                     ▼
┌─────────────────┐                 ┌─────────────────┐
│  Capability     │◀────────────────│  Capability     │
│  Update Local   │   Sync Packet   │  Update Server  │
└─────────────────┘                 └─────────────────┘
        │                                     │
        ▼                                     ▼
┌─────────────────┐                 ┌─────────────────┐
│  Visual FX      │                 │  Game Logic     │
│  - Overlay      │                 │  - Time Slow    │
│  - Scan Lines   │                 │  - AI Effects   │
└─────────────────┘                 └─────────────────┘
```

---

## Quickhack Execution Flow

```
1. INITIATION
   │
   ├─ Player opens GUI (right-click)
   ├─ EntityTargeting finds target
   └─ GUI displays available hacks
   
2. SELECTION
   │
   ├─ Player clicks quickhack button
   ├─ Client validates cooldown
   └─ Client sends CastQuickhackPacket
   
3. SERVER VALIDATION
   │
   ├─ Check cooldown in capability
   ├─ Verify target exists
   ├─ Check target in range
   └─ If valid → continue, else → ignore
   
4. UPLOAD START
   │
   ├─ QuickhackManager creates UploadData
   ├─ Server sets cooldown
   ├─ Server sends SyncCooldownPacket
   └─ Client updates UI
   
5. UPLOAD PROGRESS (every tick)
   │
   ├─ Server decrements upload timer
   ├─ Server checks cancel conditions:
   │  ├─ Target dead? → Cancel
   │  ├─ Target too far? → Cancel
   │  └─ Caster dead? → Cancel
   ├─ Server sends SyncUploadProgressPacket
   └─ Client updates progress bar
   
6. EXECUTION
   │
   ├─ Upload timer reaches 0
   ├─ Server calls quickhack.execute()
   ├─ Effects applied to target
   ├─ Particles spawned
   ├─ Sounds played
   └─ Server sends completion packet
   
7. CLEANUP
   │
   ├─ Client clears progress bar
   ├─ Cooldown ticks down over time
   └─ Capability synced on logout
```

---

## Data Storage Architecture

```
PLAYER CAPABILITY (NBT)
═══════════════════════

┌──────────────────────────────────┐
│  CompoundTag "Cooldowns"         │
│  ├─ "ping" → 150 (ticks left)    │
│  ├─ "overheat" → 0 (ready)       │
│  ├─ "short_circuit" → 200        │
│  └─ ...                          │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│  Boolean "ScanMode"              │
│  └─ true/false                   │
└──────────────────────────────────┘

ITEM INTERNAL INVENTORY (NBT)
══════════════════════════════

┌──────────────────────────────────┐
│  ListTag "Inventory"             │
│  ├─ [0] CompoundTag (ItemStack)  │
│  ├─ [1] CompoundTag (ItemStack)  │
│  ├─ [2] CompoundTag (empty)      │
│  ├─ ...                          │
│  └─ [5] CompoundTag (empty)      │
└──────────────────────────────────┘
```

---

## Scan Mode System Flow

```
ACTIVATION
══════════

User presses Z
    │
    ├─ ClientEventHandler detects
    │
    ├─ Check: Cyberdeck in main hand?
    │   ├─ Yes → Continue
    │   └─ No  → Ignore
    │
    ├─ Toggle capability.scanModeActive
    │
    ├─ Send ToggleScanModePacket to server
    │
    └─ Apply client effects immediately


SERVER PROCESSING
═════════════════

Receive ToggleScanModePacket
    │
    ├─ Update capability on server
    │
    ├─ Send SyncScanModePacket back
    │
    └─ TimeSlowManager tracks active player


TICK EFFECTS (Server)
═══════════════════════

Every tick:
    │
    ├─ For each LivingEntity
    │   ├─ Check if any player has scan mode
    │   ├─ If yes → multiply delta movement by 0.15
    │   └─ Apply slowed movement
    │
    └─ Player is also slowed


VISUAL EFFECTS (Client)
════════════════════════

Every render frame:
    │
    ├─ Check capability.isScanModeActive()
    │
    ├─ If active:
    │   ├─ Render dark overlay
    │   ├─ Render corner brackets
    │   ├─ Render scan lines
    │   └─ Apply pulsing effects
    │
    └─ Continue normal render
```

---

## Quickhack Implementation Pattern

```
ABSTRACT PATTERN
════════════════

class MyQuickhack implements Quickhack {
    
    @Override
    getId()              → Unique string ID
    
    @Override
    getName()            → Display name for UI
    
    @Override
    getCooldownTicks()   → Duration in ticks (20/sec)
    
    @Override
    getUploadTimeTicks() → Delay before execution
    
    @Override
    execute(caster, target) {
        // 1. Apply effects to target
        // 2. Spawn particles
        // 3. Play sounds
        // 4. Modify AI (if needed)
    }
}


REGISTRATION
════════════

QuickhackRegistry.register() {
    registerQuickhack(new MyQuickhack());
}
```

---

## Network Packet Flow Diagram

```
CLIENT                          SERVER
══════                          ══════

┌──────────────┐               ┌──────────────┐
│ GUI / Input  │               │              │
└──────┬───────┘               │              │
       │                        │              │
       │ CastQuickhackPacket   │              │
       ├──────────────────────▶│ Validate     │
       │                        │ Start Upload │
       │                        └──────┬───────┘
       │                               │
       │  SyncCooldownPacket           │
       │◀──────────────────────────────┤
       │                               │
       │  SyncUploadProgressPacket (x60)
       │◀──────────────────────────────┤
       │                               │
       │                        Execute Effect
       │                               │
       │  SyncUploadProgressPacket     │
       │  (finished=true)               │
       │◀──────────────────────────────┤
       │                               │
┌──────▼───────┐               ┌──────▼───────┐
│ Update UI    │               │ Game State   │
│ Clear Bar    │               │ Updated      │
└──────────────┘               └──────────────┘
```

---

## Targeting System Flow

```
EntityTargeting.getTargetedEntity(player, range)
    │
    ├─ Get eye position
    │
    ├─ Get look vector
    │
    ├─ Calculate end position (eye + look * range)
    │
    ├─ Create AABB search box
    │
    ├─ ProjectileUtil.getEntityHitResult()
    │   ├─ Filter: LivingEntity only
    │   ├─ Filter: Not spectator
    │   └─ Filter: Pickable
    │
    ├─ Check for block obstruction
    │   ├─ Raytrace blocks
    │   ├─ Compare distances
    │   └─ Block closer? → No target
    │
    └─ Return entity or null
```

---

## GUI Component Layout

```
┌──────────────────────────────────────┐
│          CYBERDECK                    │  ← Title
├──────────────────────────────────────┤
│     Target: Zombie                    │  ← Target display
├──────────────────────────────────────┤
│                                       │
│  ┌──────────────────────────────┐   │
│  │  Ping                        │   │  ← Quickhack button
│  └──────────────────────────────┘   │
│                                       │
│  ┌──────────────────────────────┐   │
│  │  Overheat          (5.2s)    │   │  ← On cooldown
│  └──────────────────────────────┘   │
│                                       │
│  ┌──────────────────────────────┐   │
│  │  Short Circuit               │   │
│  └──────────────────────────────┘   │
│                                       │
│  ... (3 more buttons)                │
│                                       │
├──────────────────────────────────────┤
│  ┌────────────────────────────┐     │
│  │ Uploading... 45%     ████  │     │  ← Progress bar
│  └────────────────────────────┘     │
└──────────────────────────────────────┘
```

---

## Event System Integration

```
FORGE EVENT BUS
═══════════════

Server Side:
├─ LivingTickEvent
│  ├─ TimeSlowManager.onLivingUpdate()
│  └─ FriendlyFireTracker.onLivingUpdate()
│
├─ ServerTickEvent
│  └─ QuickhackManager.tick()
│
└─ AttachCapabilitiesEvent<Entity>
   └─ Attach CyberdeckCapability to players

Client Side:
├─ InputEvent.Key
│  └─ ClientEventHandler.onKeyInput()
│
├─ ClientTickEvent
│  └─ ClientEventHandler.onClientTick()
│
└─ RenderGuiOverlayEvent
   └─ ScanModeRenderer.onRenderOverlay()
```

---

## Cooldown Management

```
COOLDOWN LIFECYCLE
══════════════════

Cast Quickhack
    │
    ├─ Server: capability.setCooldown("hack_id", 200)
    │
    ├─ Server → Client: SyncCooldownPacket
    │
    └─ Client: capability.setCooldown("hack_id", 200)

Every Tick (both sides):
    │
    ├─ capability.tick()
    │   ├─ For each cooldown:
    │   │   ├─ Decrement by 1
    │   │   └─ If <= 0: remove from map
    │   └─ Continue
    │
    └─ GUI queries cooldown for display

On Player Logout:
    │
    ├─ Capability saves to NBT
    │
    └─ cooldowns persisted

On Player Login:
    │
    ├─ Capability loads from NBT
    │
    └─ Cooldowns restored
```

---

## File Dependencies Graph

```
CyberdeckMod.java
    ├─ items/CyberdeckItem.java
    ├─ network/PacketHandler.java
    ├─ capability/CyberdeckCapability.java
    ├─ quickhacks/QuickhackRegistry.java
    └─ client/KeyBindings.java

CyberdeckItem.java
    └─ client/gui/CyberdeckScreen.java

CyberdeckScreen.java
    ├─ quickhacks/QuickhackRegistry.java
    ├─ capability/CyberdeckCapability.java
    ├─ network/CastQuickhackPacket.java
    ├─ util/EntityTargeting.java
    └─ client/ClientUploadTracker.java

QuickhackRegistry.java
    └─ quickhacks/impl/*

QuickhackManager.java
    ├─ quickhacks/Quickhack.java
    └─ network/SyncUploadProgressPacket.java

TimeSlowManager.java
    └─ (standalone, event-based)

ClientEventHandler.java
    ├─ client/KeyBindings.java
    ├─ capability/CyberdeckCapability.java
    ├─ network/ToggleScanModePacket.java
    └─ util/TimeSlowManager.java
```

---

This architecture allows for:
- Clean separation of concerns
- Easy testing of individual components
- Simple addition of new quickhacks
- Clear client-server boundaries
- Efficient networking
- Modular expansion

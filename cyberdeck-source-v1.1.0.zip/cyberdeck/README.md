# Cyberdeck Mod - Complete Implementation Guide

## Overview
A Minecraft Forge 1.21.10 mod that adds a cyberpunk-themed quickhacking system with time manipulation mechanics.

## Features
- **Cyberdeck Item**: Creative-only item with internal inventory structure
- **Equipable as Helmet**: Can be worn in the head slot OR held in main hand
- **Scan Mode**: Time-slow effect activated by Z key (requires Cyberdeck equipped or in main hand)
- **6 Quickhacks**: Each with unique effects, cooldowns, and upload times
- **No Progression System**: No RAM, leveling, skills, or upgrades

---

## Architecture Overview

### Package Structure
```
com.cyberdeck/
├── CyberdeckMod.java              # Main mod class
├── items/
│   └── CyberdeckItem.java         # Cyberdeck item with internal inventory
├── network/
│   ├── PacketHandler.java         # Network registration
│   ├── ToggleScanModePacket.java  # Scan mode sync
│   ├── CastQuickhackPacket.java   # Quickhack execution
│   ├── SyncCooldownPacket.java    # Cooldown sync
│   └── SyncUploadProgressPacket.java # Upload progress sync
├── capability/
│   ├── ICyberdeckCapability.java  # Capability interface
│   └── CyberdeckCapability.java   # Player data storage
├── quickhacks/
│   ├── Quickhack.java             # Base interface
│   ├── QuickhackRegistry.java     # Quickhack registration
│   ├── QuickhackManager.java      # Server-side upload tracking
│   └── impl/
│       ├── PingQuickhack.java
│       ├── OverheatQuickhack.java
│       ├── ShortCircuitQuickhack.java
│       ├── AttackGlitchQuickhack.java
│       ├── RebootOpticsQuickhack.java
│       └── FriendlyFireQuickhack.java
├── client/
│   ├── KeyBindings.java           # Z key registration
│   ├── ClientEventHandler.java    # Key input handling
│   ├── ClientUploadTracker.java   # Client-side upload state
│   ├── gui/
│   │   └── CyberdeckScreen.java   # Quickhack selection GUI
│   └── renderer/
│       └── ScanModeRenderer.java  # Visual effects
└── util/
    ├── EntityTargeting.java       # Ray trace targeting
    └── TimeSlowManager.java       # Scan mode time effects
```

---

## Core Systems

### 1. Cyberdeck Item
**File**: `items/CyberdeckItem.java`

**Features**:
- Creative-only (added to Combat creative tab)
- Equipable as helmet (head slot) via Equipable interface
- Can also be held in main hand
- Internal inventory with 6 slots (empty, for future extensions)
- Right-click opens quickhack GUI
- NBT storage for internal items

**Key Methods**:
```java
ItemStack getStackInSlot(ItemStack cyberdeck, int slot)
void setStackInSlot(ItemStack cyberdeck, int slot, ItemStack stack)
EquipmentSlot getEquipmentSlot() // Returns HEAD slot
```

---

### 2. Capability System
**Files**: `capability/CyberdeckCapability.java`, `ICyberdeckCapability.java`

**Purpose**: Store per-player data (cooldowns, scan mode state, upload state)

**Stored Data**:
- Cooldown timers (Map<String, Integer>)
- Scan mode active state (boolean)
- Currently uploading quickhack (String)

**Persistence**: NBT serialization for cooldowns and scan mode

**Key Methods**:
```java
void setCooldown(String quickhackId, int ticks)
int getCooldown(String quickhackId)
boolean isOnCooldown(String quickhackId)
void tick() // Decrements cooldowns
void setScanModeActive(boolean active)
boolean isScanModeActive()
```

---

### 3. Network System
**File**: `network/PacketHandler.java`

**Packets**:

1. **ToggleScanModePacket** (Client → Server)
   - Sent when player presses Z
   - Server validates and syncs back

2. **CastQuickhackPacket** (Client → Server)
   - Sent when player selects quickhack from GUI
   - Server validates cooldown, target, and starts upload

3. **SyncCooldownPacket** (Server → Client)
   - Syncs cooldown state after quickhack cast
   - Updates client capability

4. **SyncScanModePacket** (Server → Client)
   - Syncs scan mode state
   - Enables client-side visual effects

5. **SyncUploadProgressPacket** (Server → Client)
   - Updates upload progress bar
   - Sent every tick during upload

---

### 4. Quickhack System

#### Base Interface
**File**: `quickhacks/Quickhack.java`

```java
interface Quickhack {
    String getId();              // Unique identifier
    String getName();            // Display name
    int getCooldownTicks();      // Cooldown duration
    int getUploadTimeTicks();    // Delay before execution
    void execute(Player caster, LivingEntity target);
    boolean canCastOn(LivingEntity target);
}
```

#### Registry
**File**: `quickhacks/QuickhackRegistry.java`

- Stores all quickhacks in LinkedHashMap (preserves order)
- Provides lookup by ID
- Returns all quickhacks for GUI display

#### Upload Manager
**File**: `quickhacks/QuickhackManager.java`

**Server-side only**

**Responsibilities**:
- Track active uploads per player (UUID → UploadData)
- Tick upload progress
- Cancel uploads if:
  - Target dies
  - Target moves out of range (>30 blocks)
  - Caster dies
- Execute quickhack when upload completes
- Sync progress to client every tick

**Upload Flow**:
1. Client sends CastQuickhackPacket
2. Server creates UploadData
3. Server ticks upload counter
4. Server sends SyncUploadProgressPacket each tick
5. On completion, execute() is called
6. Server sends completion packet

---

### 5. Quickhack Implementations

#### 1. Ping
- **Cooldown**: 10 seconds
- **Upload**: Instant
- **Effect**: Apply Glowing effect to all mobs within 100 blocks for 30 seconds
- **Particles**: Electric sparks

#### 2. Overheat
- **Cooldown**: 20 seconds
- **Upload**: 0.25 seconds
- **Effect**: Set target on fire for 15 seconds
- **Particles**: Flames
- **Sound**: Fire charge

#### 3. Short Circuit
- **Cooldown**: 10 seconds
- **Upload**: 3 seconds
- **Effect**: Deal 20-50 random damage (lightning)
- **Particles**: Electric sparks + soul fire
- **Sound**: Lightning bolt impact

#### 4. Attack Glitch
- **Cooldown**: 10 seconds
- **Upload**: 0.3 seconds
- **Effect**: 
  - Mining Fatigue III (15s) - reduces attack speed
  - Weakness II (15s) - reduces damage
- **Particles**: Portal particles
- **Sound**: Enderman teleport

#### 5. Reboot Optics
- **Cooldown**: 10 seconds
- **Upload**: 0.3 seconds
- **Effect**: Blindness for 10 seconds
- **Particles**: Smoke + squid ink
- **Sound**: Ender eye death

#### 6. Friendly Fire
- **Cooldown**: 20 seconds
- **Upload**: 5 seconds
- **Effect**: 
  - Mob targets other Monster entities for 30 seconds
  - Completely ignores players
  - AI goals replaced with NearestAttackableTargetGoal<Monster>
- **Particles**: Angry villager + enchant
- **Sound**: Illusioner cast spell

**Implementation**: Event-based AI override
- Stores affected mob UUIDs with duration
- Clears target selector goals
- Adds Monster targeting goal
- Prevents player targeting
- Restores original behavior on expiration

---

### 6. Scan Mode System

#### Toggle Mechanism
**File**: `client/ClientEventHandler.java`

- Detects Z key press (KeyBindings.SCAN_MODE_KEY)
- Validates Cyberdeck is in main hand OR equipped as helmet
- Toggles capability state
- Sends ToggleScanModePacket to server

#### Time Slow Effect
**File**: `util/TimeSlowManager.java`

**Server-side** (applies to all entities):
- Tracks players with scan mode active
- On LivingTickEvent:
  - Scales entity delta movement by 0.15 (85% reduction)
  - Applies to ALL entities when any player has scan mode active
  - Player is also slowed

**Why this approach**:
- No per-entity tracking needed
- Global effect is simple and performant
- Player can still interact (upload quickhacks)

#### Visual Effects
**File**: `client/renderer/ScanModeRenderer.java`

**Rendered on RenderGuiOverlayEvent**:
- Dark cyan vignette overlay (pulsing alpha)
- Corner brackets (cyberpunk HUD style)
- Animated scan lines (scrolling effect)
- All effects pulse in sync

**Colors**:
- Overlay: `0x001a1a` (dark cyan)
- Brackets: `0x00FFFF` (cyan)
- Scan lines: `0x20FFFFFF` (semi-transparent white)

---

### 7. Targeting System
**File**: `util/EntityTargeting.java`

**Method**: `getTargetedEntity(Player player, double range)`

**Implementation**:
1. Get player eye position and look vector
2. Calculate end position (eye + look * range)
3. Create AABB search box
4. Use ProjectileUtil.getEntityHitResult()
5. Filter for LivingEntity only
6. Check for block obstruction
7. Return closest valid target or null

**Range**: 25 blocks (configurable in code)

---

### 8. GUI System
**File**: `client/gui/CyberdeckScreen.java`

**Layout**:
- Title: "Cyberdeck"
- Target display: Shows current target or "No Target"
- Quickhack buttons: Vertical list
  - Button shows name
  - Grayed out if on cooldown
  - Shows cooldown timer
- Upload progress bar: Bottom of screen

**Button States**:
- **Available**: Cyan border, light background, white text
- **On Cooldown**: Gray border, dark background, gray text with timer
- **No Target**: All buttons grayed

**Interaction**:
- Left-click button to cast quickhack
- Validates cooldown and target
- Sends CastQuickhackPacket
- Closes GUI on successful cast

---

## Data Flow Examples

### Casting a Quickhack

```
1. CLIENT: Player opens GUI (right-click Cyberdeck)
2. CLIENT: GUI finds target via EntityTargeting
3. CLIENT: Player clicks "Short Circuit" button
4. CLIENT: Validates cooldown locally
5. CLIENT → SERVER: CastQuickhackPacket("short_circuit")
6. SERVER: Receives packet
7. SERVER: Validates cooldown in capability
8. SERVER: Finds target entity
9. SERVER: Creates UploadData in QuickhackManager
10. SERVER: Sets cooldown in capability
11. SERVER → CLIENT: SyncCooldownPacket("short_circuit", 200)
12. SERVER: Starts ticking upload
13. SERVER → CLIENT: SyncUploadProgressPacket (every tick)
14. CLIENT: Updates progress bar
15. SERVER: Upload completes after 60 ticks (3 seconds)
16. SERVER: Executes quickhack (damage + effects)
17. SERVER → CLIENT: SyncUploadProgressPacket (finished=true)
18. CLIENT: Clears progress bar
```

### Toggling Scan Mode

```
1. CLIENT: Player presses Z key
2. CLIENT: Validates Cyberdeck in main hand
3. CLIENT: Toggles capability state locally
4. CLIENT: Applies TimeSlowManager.setScanMode()
5. CLIENT → SERVER: ToggleScanModePacket(true)
6. SERVER: Receives packet
7. SERVER: Sets capability state
8. SERVER → CLIENT: SyncScanModePacket(true)
9. SERVER: On LivingTickEvent, applies slow to all entities
10. CLIENT: Renders visual overlay
11. (Player presses Z again)
12. CLIENT: Toggles off
13. CLIENT → SERVER: ToggleScanModePacket(false)
14. SERVER: Clears scan mode
15. SERVER: Entities return to normal speed
```

---

## Building the Mod

### Prerequisites
- Java 21 JDK
- Gradle 8.x
- Minecraft Forge 1.21.1-51.0.33

### Build Steps
```bash
cd cyberdeck
./gradlew build
```

Output: `build/libs/cyberdeck-1.0.0.jar`

### Running in Dev
```bash
./gradlew runClient  # Client
./gradlew runServer  # Dedicated server
```

---

## Testing Checklist

### Basic Functionality
- [ ] Cyberdeck appears in Creative Combat tab
- [ ] Right-click opens GUI
- [ ] GUI shows all 6 quickhacks

### Scan Mode
- [ ] Z key toggles scan mode (with Cyberdeck in main hand)
- [ ] Visual overlay appears
- [ ] All entities slow down (including player)
- [ ] Player can still upload quickhacks
- [ ] Z key does nothing without Cyberdeck

### Targeting
- [ ] Crosshair targeting works up to 25 blocks
- [ ] Blocks obstruct targeting
- [ ] "No Target" shows when not looking at entity

### Cooldowns
- [ ] Cooldown starts after casting
- [ ] GUI shows cooldown timer
- [ ] Cannot cast while on cooldown
- [ ] Cooldown persists through logout/login

### Upload System
- [ ] Progress bar appears during upload
- [ ] Upload cancels if target dies
- [ ] Upload cancels if target moves too far
- [ ] Effect executes after upload completes

### Quickhacks
- [ ] **Ping**: All mobs glow for 30s
- [ ] **Overheat**: Target burns for 15s
- [ ] **Short Circuit**: Random 20-50 damage + particles
- [ ] **Attack Glitch**: Reduced attack speed/damage
- [ ] **Reboot Optics**: Blindness for 10s
- [ ] **Friendly Fire**: Mob attacks other mobs, not player

---

## Configuration

All values are hardcoded but easily modifiable:

**Cooldowns** (in quickhack impl files):
- Ping: 200 ticks (10s)
- Overheat: 400 ticks (20s)
- Short Circuit: 200 ticks (10s)
- Attack Glitch: 200 ticks (10s)
- Reboot Optics: 200 ticks (10s)
- Friendly Fire: 400 ticks (20s)

**Upload Times**:
- Ping: 1 tick (instant)
- Overheat: 5 ticks (0.25s)
- Short Circuit: 60 ticks (3s)
- Attack Glitch: 6 ticks (0.3s)
- Reboot Optics: 6 ticks (0.3s)
- Friendly Fire: 100 ticks (5s)

**Other**:
- Targeting range: 25 blocks (EntityTargeting.java)
- Ping radius: 100 blocks (PingQuickhack.java)
- Upload cancel range: 30 blocks (QuickhackManager.java)
- Scan mode slow factor: 0.15 (TimeSlowManager.java)

---

## Known Limitations

1. **Friendly Fire AI**: Basic implementation that clears goals. More robust system would save/restore original goal priorities.

2. **Scan Mode Time Slow**: Affects all entities globally when any player has scan mode active. More advanced implementation could use attribute modifiers.

3. **No Config File**: All values are hardcoded. Could add Forge config system.

4. **No Custom Particles**: Uses vanilla particles. Custom particles would require additional resource files.

5. **Internal Inventory**: Structure exists but not used. Future extensions would populate these slots.

---

## Future Extension Points

The mod is designed for easy extension:

### Adding New Quickhacks
1. Create class implementing `Quickhack` interface
2. Register in `QuickhackRegistry.register()`
3. Add translation in `en_us.json`

### Adding Internal Item Support
- Use `CyberdeckItem.getStackInSlot()` / `setStackInSlot()`
- Create container/screen for inventory management
- Add custom item effects in quickhack execution

### Adding Config
- Use ForgeConfigSpec
- Add config values for cooldowns, ranges, durations
- Reference config in quickhack implementations

---

## Credits
- Designed for Minecraft Forge 1.21.10
- Follows Forge best practices for capabilities, networking, and events
- No mixins required

# 🔧 How to Build the Cyberdeck Mod

This guide will walk you through building the mod from source into a working `.jar` file.

---

## 📋 Prerequisites

You'll need these installed on your computer:

### 1. Java Development Kit (JDK) 21
- **Download**: https://adoptium.net/temurin/releases/
- Choose: JDK 21 (LTS)
- Install for your operating system

**Verify installation:**
```bash
java -version
```
Should show: `openjdk version "21.0.x"`

### 2. Git (Optional, for cloning)
- **Download**: https://git-scm.com/downloads
- Not required if you download the folder directly

---

## 🚀 Method 1: Building with Gradle (Recommended)

### Step 1: Extract the Mod
1. Download the `cyberdeck` folder
2. Extract it to a location like:
   - Windows: `C:\Projects\cyberdeck`
   - Mac/Linux: `~/Projects/cyberdeck`

### Step 2: Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`
- Type `cmd` and press Enter
- Navigate: `cd C:\Projects\cyberdeck`

**Mac/Linux:**
- Open Terminal
- Navigate: `cd ~/Projects/cyberdeck`

### Step 3: Build the Mod

Run this command:

**Windows:**
```bash
gradlew.bat build
```

**Mac/Linux:**
```bash
chmod +x gradlew
./gradlew build
```

### Step 4: Wait for Build

You'll see output like:
```
> Task :compileJava
> Task :processResources
> Task :classes
> Task :jar
> Task :reobfJar

BUILD SUCCESSFUL in 2m 34s
```

### Step 5: Find Your Mod

The compiled mod will be at:
```
cyberdeck/build/libs/cyberdeck-1.1.0.jar
```

🎉 **This is your mod file!**

---

## 📦 Method 2: Building with IDE (Advanced)

### Using IntelliJ IDEA

#### 1. Import Project
- Open IntelliJ IDEA
- Click: `File` → `Open`
- Select the `cyberdeck` folder
- Click: `Open as Project`

#### 2. Wait for Gradle Sync
- IntelliJ will automatically detect `build.gradle`
- Wait for dependencies to download (first time takes ~5-10 minutes)
- Watch the progress bar at bottom of window

#### 3. Run Gradle Build
- Open Gradle panel (right side of window)
- Navigate: `cyberdeck` → `Tasks` → `build`
- Double-click `build`

#### 4. Find Your Mod
- Check: `build/libs/cyberdeck-1.1.0.jar`

### Using Eclipse

#### 1. Import Project
- Open Eclipse
- Click: `File` → `Import` → `Gradle` → `Existing Gradle Project`
- Select the `cyberdeck` folder
- Click: `Finish`

#### 2. Build
- Right-click project → `Gradle` → `Tasks Quick Launcher`
- Type: `build`
- Press Enter

#### 3. Find Your Mod
- Refresh project (`F5`)
- Check: `build/libs/cyberdeck-1.1.0.jar`

---

## 🎮 Testing Your Build

### Option 1: In Development Environment

**Run Client:**
```bash
./gradlew runClient
```

This launches Minecraft with the mod pre-loaded for testing.

**Run Server:**
```bash
./gradlew runServer
```

### Option 2: In Regular Minecraft

1. **Install Forge:**
   - Download Forge 1.21.1 installer: https://files.minecraftforge.net/
   - Run the installer
   - Select "Install Client"

2. **Copy Mod:**
   - Copy `build/libs/cyberdeck-1.1.0.jar`
   - Paste into: `.minecraft/mods/` folder
   
3. **Launch:**
   - Open Minecraft Launcher
   - Select Forge 1.21.1 profile
   - Click Play

4. **Verify:**
   - In main menu, click "Mods"
   - Look for "Cyberdeck v1.1.0"

---

## 🛠️ Troubleshooting

### "Command not found: gradlew"

**Problem:** Gradle wrapper not found  
**Solution:** Make sure you're in the `cyberdeck` folder
```bash
cd cyberdeck
ls -la   # Should show gradlew file
```

### "Java version mismatch"

**Problem:** Wrong Java version  
**Solution:** Install JDK 21 and set JAVA_HOME
```bash
# Windows (PowerShell)
$env:JAVA_HOME = "C:\Program Files\Java\jdk-21"

# Mac/Linux
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk
```

### "Could not resolve dependencies"

**Problem:** Network/repository issues  
**Solution:** Check internet connection, try again
```bash
./gradlew build --refresh-dependencies
```

### "BUILD FAILED" with errors

**Problem:** Code compilation errors  
**Solution:** 
1. Make sure all files are intact
2. Check you didn't modify any `.java` files
3. Re-download the original mod folder

### "Task :reobfJar FAILED"

**Problem:** Forge obfuscation issue  
**Solution:** Clean and rebuild
```bash
./gradlew clean
./gradlew build
```

### Gradle is downloading forever

**Problem:** First-time setup downloads many dependencies  
**Solution:** This is normal! First build takes 5-15 minutes. Subsequent builds are faster (~30 seconds).

---

## 📂 Project Structure

```
cyberdeck/
├── src/
│   └── main/
│       ├── java/          ← Java source code
│       └── resources/     ← Assets (textures, models, etc.)
├── build/
│   └── libs/
│       └── cyberdeck-1.1.0.jar  ← YOUR MOD FILE
├── gradle/                ← Gradle wrapper files
├── build.gradle           ← Build configuration
├── settings.gradle        ← Project settings
└── gradlew               ← Gradle wrapper script
```

---

## 🔄 Rebuilding After Changes

If you modify the code:

1. **Clean old build:**
   ```bash
   ./gradlew clean
   ```

2. **Build again:**
   ```bash
   ./gradlew build
   ```

3. **New JAR will overwrite the old one**

---

## 📤 Distributing Your Mod

### What to Share

Share the **JAR file only**:
- `build/libs/cyberdeck-1.1.0.jar`

**Don't share:**
- The entire `cyberdeck` folder
- The `build` folder (except the JAR)
- The `src` folder (unless distributing source code)

### Where to Upload

- **CurseForge**: https://www.curseforge.com/minecraft/mc-mods
- **Modrinth**: https://modrinth.com/
- **GitHub Releases**: If you have a GitHub repo
- **Discord/Community**: Direct file sharing

---

## 🎯 Quick Reference

### Build Commands

```bash
# Clean build files
./gradlew clean

# Build the mod
./gradlew build

# Run client for testing
./gradlew runClient

# Run server for testing
./gradlew runServer

# Build without testing
./gradlew build -x test
```

### Important Files

- **Output**: `build/libs/cyberdeck-1.1.0.jar`
- **Main Mod**: `src/main/java/com/cyberdeck/CyberdeckMod.java`
- **Texture**: `src/main/resources/assets/cyberdeck/textures/item/cyberdeck.png`

---

## ✅ Verification Checklist

After building, verify:

- [ ] File exists: `build/libs/cyberdeck-1.1.0.jar`
- [ ] File size is reasonable (>100 KB, usually ~200-500 KB)
- [ ] File opens in archive tool (7-Zip, WinRAR)
- [ ] Contains `META-INF/mods.toml` when opened
- [ ] Contains compiled `.class` files, not `.java` files

---

## 🎊 Success!

If you see:
```
BUILD SUCCESSFUL in 2m 34s
```

And you have:
```
build/libs/cyberdeck-1.1.0.jar
```

**You're done!** 🚀

Copy that JAR to your `.minecraft/mods` folder and play!

---

## 💡 Pro Tips

1. **Keep source code**: The `cyberdeck` folder is your source. Keep it safe!

2. **Version control**: Use Git to track changes
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   ```

3. **Fast rebuilds**: After first build, subsequent builds are much faster

4. **Dev environment**: Use `runClient` to test without copying to mods folder

5. **Logs location**: `run/logs/latest.log` when using `runClient`

---

## 📞 Need Help?

If you encounter issues:

1. Read the error message carefully
2. Check this troubleshooting section
3. Verify prerequisites (Java 21)
4. Try cleaning: `./gradlew clean`
5. Try with `--stacktrace` for details: `./gradlew build --stacktrace`

Most issues are solved by ensuring Java 21 is correctly installed and set as default.

# 🎮 Cyberdeck Mod v1.1.0

A cyberpunk-themed quickhacking mod for Minecraft Forge 1.21.1

![Cyberdeck Item](src/main/resources/assets/cyberdeck/textures/item/cyberdeck.png)

---

## 🚀 Quick Start

### For Players - Installing the Mod

**Option 1: Download Pre-built (Easiest)**
- Look for `cyberdeck-1.1.0.jar` in the releases
- Drop it into your `.minecraft/mods/` folder
- Requires Forge 1.21.1

**Option 2: Build From Source**
1. Make sure you have Java 21 installed
2. Run: `./gradlew build` (Mac/Linux) or `gradlew.bat build` (Windows)
3. Find your mod: `build/libs/cyberdeck-1.1.0.jar`

📖 **Detailed instructions**: See [BUILD_TUTORIAL.md](BUILD_TUTORIAL.md)

---

## ✨ Features

- **Cyberdeck Item**: Creative-only item that can be equipped as a helmet or held in hand
- **Scan Mode**: Press Z to slow time (works when equipped or held)
- **6 Quickhacks**: Ping, Overheat, Short Circuit, Attack Glitch, Reboot Optics, Friendly Fire
- **No Progression**: No RAM, XP, or leveling - just pure hacking fun

---

## 📚 Documentation

- **[BUILD_TUTORIAL.md](BUILD_TUTORIAL.md)** - How to compile the mod
- **[QUICK_START.md](QUICK_START.md)** - User guide for playing
- **[README.md](README.md)** - Complete technical documentation
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System diagrams and flows
- **[CHANGELOG.md](CHANGELOG.md)** - Version history
- **[UPDATE_v1.1.0.md](UPDATE_v1.1.0.md)** - Latest update details

---

## 🎯 How to Play

1. Get the Cyberdeck from Creative mode (Combat tab)
2. Equip it as a helmet OR hold in main hand
3. Press Z for scan mode (slows time)
4. Right-click to open quickhack menu
5. Select a hack and watch it upload!

---

## 🛠️ Requirements

**To Build:**
- Java Development Kit 21
- Gradle (included via wrapper)

**To Play:**
- Minecraft 1.21.1
- Forge 1.21.1 (version 51.0.33+)

---

## 📦 Project Structure

```
cyberdeck/
├── src/main/java/           # Java source code
├── src/main/resources/      # Textures, models, configs
├── build/libs/              # Compiled mod (after building)
├── gradle/                  # Gradle wrapper
├── build.gradle             # Build configuration
└── *.md                     # Documentation
```

---

## 🔧 Building

**Windows:**
```bash
gradlew.bat build
```

**Mac/Linux:**
```bash
./gradlew build
```

**Output:** `build/libs/cyberdeck-1.1.0.jar`

---

## 🎮 Testing in Dev Environment

```bash
./gradlew runClient    # Launch Minecraft with mod loaded
./gradlew runServer    # Launch server with mod loaded
```

---

## 📄 License

This project is provided as-is. Feel free to modify and distribute.

---

## 🙏 Credits

- Texture design provided by user
- Built with Minecraft Forge
- Follows Forge modding best practices

---

## 🐛 Issues?

Check the troubleshooting section in [BUILD_TUTORIAL.md](BUILD_TUTORIAL.md)

Common issues:
- "Java version mismatch" → Install JDK 21
- "gradlew not found" → Make sure you're in the cyberdeck folder
- "BUILD FAILED" → Try `./gradlew clean` first

---

**Version**: 1.1.0  
**Minecraft**: 1.21.1  
**Forge**: 51.0.33+  
**Last Updated**: 2024

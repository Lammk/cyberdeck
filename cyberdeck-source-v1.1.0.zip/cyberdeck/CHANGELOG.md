# Cyberdeck Mod - Changelog

## Version 1.1.0 (Current)

### Added
- **Helmet Equipping**: Cyberdeck can now be equipped in the head slot as a helmet
  - Implements `Equipable` interface
  - Returns `EquipmentSlot.HEAD` 
  - Works exactly like vanilla helmets
  
### Changed
- **Scan Mode**: Now activates with Cyberdeck in main hand OR equipped as helmet
  - Updated `ClientEventHandler.handleScanModeToggle()` to check both slots
  - Check order: main hand OR head armor slot
  - Provides hands-free operation when worn as helmet

### Technical Details
- Modified `CyberdeckItem.java`:
  - Added `implements Equipable`
  - Added `getEquipmentSlot()` method returning `EquipmentSlot.HEAD`
  
- Modified `ClientEventHandler.java`:
  - Updated scan mode validation to check helmet slot: `player.getInventory().getArmor(3)`
  - Uses logical OR to accept either main hand or helmet

### Benefits
- **Hands-free operation**: Wear as helmet and use other items while maintaining scan mode access
- **Tactical flexibility**: Choose between holding for quickhacks or wearing for passive availability
- **Cyberpunk aesthetic**: Wearing a cyberdeck as headgear fits the theme

---

## Version 1.0.0 (Initial Release)

### Features
- Cyberdeck item (Creative-only, Combat tab)
- 6 Quickhacks with cooldowns and upload times
- Scan mode with time-slow effects
- Full client-server synchronization
- Persistent cooldowns
- Upload progress tracking
- Entity targeting system
- Visual effects and GUI

### Quickhacks
1. Ping - Track all mobs
2. Overheat - Burn target
3. Short Circuit - Electric damage
4. Attack Glitch - Weaken target
5. Reboot Optics - Blind target
6. Friendly Fire - Turn mob against others

### Technical
- Forge 1.21.10 compatible
- Capability-based player data
- Packet-based networking
- Event-driven architecture
- No mixins required

# Cyberdeck Mod - Quick Start Guide

## Installation

### For Players
1. Download the mod JAR file (`cyberdeck-1.0.0.jar`)
2. Install Minecraft Forge 1.21.1 (version 51.0.33 or higher)
3. Place the JAR file in your `.minecraft/mods` folder
4. Launch Minecraft with the Forge profile

### For Developers
1. Extract the mod source code
2. Open terminal in the `cyberdeck` folder
3. Run `./gradlew build` (Linux/Mac) or `gradlew.bat build` (Windows)
4. JAR will be in `build/libs/`

---

## How to Use

### Getting the Cyberdeck
1. Enter Creative mode (`/gamemode creative`)
2. Open inventory (E)
3. Go to the "Combat" tab
4. Find the Cyberdeck item
5. Place it in your hotbar OR equip it as a helmet

### Equipping as a Helmet
1. Open your inventory (E)
2. Drag the Cyberdeck to the helmet slot
3. It will appear on your head
4. You can now use scan mode hands-free!

### Using Quickhacks
1. **Hold** the Cyberdeck in your **main hand**
2. **Look at** a mob/entity
3. **Right-click** to open the quickhack menu
4. **Click** a quickhack to cast it
5. Wait for the upload bar to complete

### Scan Mode
1. Hold the Cyberdeck in your main hand OR wear it as a helmet
2. Press **Z** to activate Scan Mode
3. Everything slows down (including you!)
4. You can still cast quickhacks while in Scan Mode
5. Press **Z** again to deactivate

---

## Quickhack Reference

| Name | Cooldown | Upload | Effect |
|------|----------|---------|--------|
| **Ping** | 10s | Instant | All mobs within 100 blocks glow for 30s |
| **Overheat** | 20s | 0.25s | Target burns for 15s |
| **Short Circuit** | 10s | 3s | Deal 20-50 damage + electric effects |
| **Attack Glitch** | 10s | 0.3s | Reduce target's attack speed and damage (15s) |
| **Reboot Optics** | 10s | 0.3s | Blind target for 10s |
| **Friendly Fire** | 20s | 5s | Target attacks other mobs (not players) for 30s |

---

## Tips

### Helmet vs. Main Hand
- **Wear as Helmet**: Hands-free scan mode, can hold other items
- **Hold in Hand**: Easier access to quickhack GUI (right-click)
- **Best of Both**: Wear it and swap to hand when you need quickhacks!

### Combat Strategy
- Use **Ping** first to reveal all enemies
- Cast **Reboot Optics** on ranged enemies (skeletons)
- Use **Friendly Fire** to create chaos in large groups
- **Short Circuit** is high risk (long upload) but high damage
- **Attack Glitch** is great for tough single targets

### Scan Mode
- Activate in dangerous situations to assess threats
- You move slower, so don't use during chases
- Great for lining up precision quickhacks
- Visual effects help you stay immersed in cyberpunk theme

### Cooldown Management
- Quickhacks with short cooldowns (10s) can be spammed
- Long cooldowns (20s) should be used strategically
- Plan your rotation: Ping → Overheat → Short Circuit → Attack Glitch

---

## Troubleshooting

### "The Cyberdeck doesn't appear in Creative!"
- Make sure you're in the **Combat** tab, not Tools or other tabs
- Verify the mod is loaded (check mods list in main menu)

### "Z key doesn't work!"
- You must **hold the Cyberdeck in your main hand OR wear it as a helmet**
- Check for key conflicts (Options → Controls → Cyberdeck category)

### "Quickhacks have no effect!"
- Make sure you're on a **server that allows the mod**
- In singleplayer, cheats must be enabled
- Check that the target is a valid LivingEntity (not armor stands, etc.)

### "Upload gets cancelled!"
- Target must stay within 30 blocks
- Target must stay alive during upload
- You must stay alive during upload

---

## Commands (for Testing)

```
/gamemode creative
/give @p cyberdeck:cyberdeck
/summon zombie ~ ~ ~5
/effect give @e[type=zombie,limit=1] glowing 30
```

---

## Mod Compatibility

### Should work with:
- Most mob mods (More Mobs, etc.)
- Combat overhaul mods
- Magic mods
- RPG mods

### Might conflict with:
- Mods that heavily modify time/tick rate
- Mods that replace AI systems
- Mods that override entity rendering

### Not compatible with:
- Versions other than 1.21.1
- Fabric (Forge only)

---

## Support

For bugs or questions:
1. Check the README.md for technical details
2. Verify you're using Forge 1.21.1
3. Test with only this mod installed
4. Check latest.log for errors

---

## Credits

**Mod Author**: [Your Name]
**Minecraft Version**: 1.21.1
**Forge Version**: 51.0.33+
**License**: MIT
